import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'molla-subservice',
  templateUrl: './subservice.component.html',
  styleUrls: ['./subservice.component.scss']
})
export class SubserviceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
