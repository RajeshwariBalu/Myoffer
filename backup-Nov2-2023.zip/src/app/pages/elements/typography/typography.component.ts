import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'elements-typography-page',
	templateUrl: './typography.component.html',
	styleUrls: ['./typography.component.scss']
})

export class TypographyPageComponent implements OnInit {

	constructor() { }

	ngOnInit(): void {
	}
}
