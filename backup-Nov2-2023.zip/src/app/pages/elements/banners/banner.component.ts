import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'elements-banners-page',
	templateUrl: './banner.component.html',
	styleUrls: ['./banner.component.scss']
})

export class BannersPageComponent implements OnInit {

	constructor() { }

	ngOnInit(): void { }
}
