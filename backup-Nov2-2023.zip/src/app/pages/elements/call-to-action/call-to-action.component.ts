import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'elements-call-to-action-page',
	templateUrl: './call-to-action.component.html',
	styleUrls: ['./call-to-action.component.scss']
})

export class CallToActionPageComponent implements OnInit {

	constructor() { }

	ngOnInit(): void {
	}
}
