import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'elements-list-page',
	templateUrl: './elements-list.component.html',
	styleUrls: ['./elements-list.component.scss']
})

export class ElementsListPageComponent implements OnInit {

	constructor() { }

	ngOnInit(): void {
	}
}
