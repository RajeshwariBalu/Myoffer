import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'elements-buttons-page',
	templateUrl: './button.component.html',
	styleUrls: ['./button.component.scss']
})

export class ButtonsPageComponent implements OnInit {

	constructor() { }

	ngOnInit(): void {
	}
}
